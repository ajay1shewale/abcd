﻿using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Threading.Tasks;
using BOL;

namespace DAL
{
    public class DBAccountManager
    {
        static string constring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Ajay\Downloads\WebApplication1\WebApplication1\App_Data\Customers.mdf;Integrated Security=True";
        public static bool Validate(string userName, string Password)
        {
            string cmdstring = "select * from Customers where Username=@username and Password=@password";
            bool status = false;
            IDbConnection con = new SqlConnection();
            con.ConnectionString = constring;
            IDbCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = cmdstring;
            cmd.Parameters.Add(new SqlParameter("@username", userName));
            cmd.Parameters.Add(new SqlParameter("@password", Password));

            IDataReader reader = null;

            try
            {
                con.Open();
                reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    status = true;
                }
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally {
                con.Close();
            }
            
            return status;
        }
        public static bool Register(Customers c)
        {
            bool status = false;
            string cmdstring = "insert into Customers (Username,Password,Email,PhoneNo,Address) values (@username,@password,@email,@phoneno,@address)";
            IDbConnection con = new SqlConnection();
            con.ConnectionString = constring;
            IDbCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = cmdstring;
            cmd.Parameters.Add(new SqlParameter("@username", c.Username));
            cmd.Parameters.Add(new SqlParameter("@Password", c.Password));
            cmd.Parameters.Add(new SqlParameter("@Email", c.Email));
            cmd.Parameters.Add(new SqlParameter("@PhoneNo", c.PhoneNo));
            cmd.Parameters.Add(new SqlParameter("@Address", c.Address));


            try
            {
                con.Open();
                int i = cmd.ExecuteNonQuery();
                if (i == 1)
                {
                    status = true;
                }

            }
            catch (SqlException e)
            {
                throw e;
            }
            finally {
                con.Close();
            }
            return status;
        }
    }
}
