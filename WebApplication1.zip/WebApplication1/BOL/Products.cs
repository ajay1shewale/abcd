﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOL
{
    public class Products
    {

        public string pname { set; get; }
        public double price { set; get; }
        public string date { set; get; }

    }
}
