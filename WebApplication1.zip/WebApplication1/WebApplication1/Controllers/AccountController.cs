﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;

namespace WebApplication1.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(string username,string password)
        {
            if (AccountManager.Validate(username, password))
            {
                return RedirectToAction("index","products");
            }
            ViewData["msg"] = "Login Unsuccessful";
            return View();
        }
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Register(string username,string password,string email,string phone,string address)
        {
            Customers c = new Customers();
            c.Username = username;
            c.Password = password;
            c.Email = email;
            c.Address = address;
            c.PhoneNo = phone;
           

            if (AccountManager.Register(c))
            {
                TempData["msg"] = "Registration Successful";
                return RedirectToAction("login","Account");
            }
            TempData["msg"] = "Registration Unsuccessful";
            return View();
        }
    }
}