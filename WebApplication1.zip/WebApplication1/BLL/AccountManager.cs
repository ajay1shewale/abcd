﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BOL;
namespace BLL
{
    public class AccountManager
    {
        public static bool Validate(string username, string password)
        {
            bool status = false;
            if (DBAccountManager.Validate(username, password))
                status = true;
            return status;

        }
        public static bool Register(Customers c)
        {
            bool status = false;
            if (DBAccountManager.Register(c))
            {
                status = true;
            }
            return status;
        }
    }
}
