﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;

namespace BLL
{
   public class AccountProducts
    {
        public static List<Products> GetAll()
        {
            List<Products> products = new List<Products>();
            //  LINQ Query
            // collection ETL
            //
            return products;
        }

    }
}
